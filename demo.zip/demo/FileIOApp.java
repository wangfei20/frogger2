package demo;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.swing.JOptionPane;


public class FileIOApp {

	public static void main(String[] args) {
		
		//write data to a file byte by byte
		String filename = JOptionPane.showInputDialog(null, 
				"Enter a filename");
		
		String data = JOptionPane.showInputDialog(null, 
				"Enter data to store");

		try {
			
			FileOutputStream outStream = 
					new FileOutputStream(filename);
			
			for (int i=0; i < data.length(); i++) {
				outStream.write( data.charAt(i) );
			}
			outStream.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		
		//read data from file
		try {
			FileInputStream inStream = 
					new FileInputStream(filename);
			
			int numBytes = inStream.available();
			byte inputBuffer[] = new byte [numBytes];
			int bytesRead = 
					inStream.read(inputBuffer, 0, numBytes);
			String text = new String(inputBuffer);

			System.out.println(bytesRead + " characters were read");
			System.out.println("The read text was: " + text);
			
			inStream.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		
		
		
	}

}
