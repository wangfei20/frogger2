
package demo;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintStream;


public class FileIOApp2 {

	public static void main(String[] args) {
		
		//set up data stream from the keyboard
		InputStreamReader isrKeyboard = 
				new InputStreamReader(System.in);
		BufferedReader keyboard = 
				new BufferedReader(isrKeyboard);
		
		try {
			System.out.println("Enter a filename: ");
			String filename = keyboard.readLine();
			
			System.out.println("Enter data to save: ");
			String data = keyboard.readLine();
			
			FileOutputStream out = new FileOutputStream(filename);
			PrintStream pStream = new PrintStream(out);
			pStream.println(data);
			out.close();
			
			BufferedReader inputReader = 
					new BufferedReader( new FileReader(filename));
			String sRead = inputReader.readLine();
			
			//String dataRead = "";
			//while
				//dataRead += inputReader.readLine();
			
			inputReader.close();
			
			System.out.println("Data read was: " + sRead );
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}

}
