package demo;

public class Character1 extends Sprite {
	
	public Character1() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Character1(int x, int y, int height, int width, String image) {
		super(x, y, height, width, image);
		// TODO Auto-generated constructor stub
	}

}
