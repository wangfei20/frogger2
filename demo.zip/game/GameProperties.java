package game;

public class GameProperties {
	
	public static final int SCREEN_HEIGHT = 730;
	public static final int SCREEN_WIDTH = 559;
	public static final int CHARACTER_STEP = 70;
	public static final int FROG_HEIGHT = 24;
	public static final int FROG_WIDTH = 32;
	public static final String FROG_IMAGE = "frog.png";
	public static final String FROG_COLLISION_IMAGE = "colfrog.png";
	
	//GameProperties myProperties = new GameProperties;
	//myProperties.CHARACTER_STEP
	
	//GameProperties.SCREEN_WIDTH

}
